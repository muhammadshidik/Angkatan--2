<!-- function
1. function yang kita buat
2. function bawaan strlen(), in_array() 
-->
<?php

// function callName()