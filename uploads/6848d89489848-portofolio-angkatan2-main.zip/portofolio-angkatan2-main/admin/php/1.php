<?php
echo "tess"; //echo mencetak string
print_r("Tess"); //menctetak type data array
print "Tess"; //string
echo "<br>";
var_dump("Tessss"); //mencetak string dan memunculkan tipe datanya

// variable 
$nama  = "Bambang Pamungkas";
echo $nama;
echo "<br>";
$umur  = 30;
echo $umur;
echo "<br>";
$tinggi_badan = 165.9;
echo $tinggi_badan;
echo "cm";
echo "<br>";

define("alamat", "Karet Jakarta Pusat");
echo alamat;
echo "<br>";
const telp = "08994212290";
echo telp;
